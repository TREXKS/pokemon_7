--[[
    GD50VIRTUAL_HEIGHT
    Pokemon

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

LevelUpState = Class{__includes = BaseState}

function LevelUpState:init(HP, attack, defense, speed, HPIncreased, attackIncreased, defenseIncreased, speedIncreased, onClose)
    -- self.textbox = Textbox(0, VIRTUAL_HEIGHT - 64, VIRTUAL_WIDTH, 64, msg, gFonts['small'])

    self.name = "LevelUpMenu"
    self.levelUpMenu = Menu {

        x = VIRTUAL_WIDTH - 200,
        y = VIRTUAL_HEIGHT - 200,
        width = 200,
        height = 200,
        hasCursor = false,
        -- items for each stats upgrade
        items = {
            {
                text = 'HP: ' .. tostring(HP) .. ' + ' ..  tostring(HPIncreased) .. ' = ' .. tostring(HP + HPIncreased),
            },
            {
                text = 'attack: ' .. tostring(attack) .. ' + ' ..  tostring(attackIncreased) .. ' = ' .. tostring(attack + attackIncreased),
            },
            {
                text = 'defense: ' .. tostring(defense) .. ' + ' ..  tostring(defenseIncreased) .. ' = ' .. tostring(defense + defenseIncreased),
            },
            {
                text = 'speed: ' .. tostring(speed) .. ' + ' ..  tostring(speedIncreased) .. ' = ' .. tostring(speed + speedIncreased),
            }
        }

    }
    -- function to be called once this message is popped
    self.onClose = onClose or function() end

end

function LevelUpState:update(dt)
    -- press to pop menu
    if love.keyboard.wasPressed('space') or love.keyboard.wasPressed('return') then
        gStateStack:pop()
        self.onClose()
    end
end

function LevelUpState:render()
    self.levelUpMenu:render()
end