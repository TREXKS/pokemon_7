--[[
    GD50
    Pokemon

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

Party = Class{}

function Party:init(def)
    self.pokemon = def.pokemon
end

function Party:update(dt)

end

function Party:render()

end